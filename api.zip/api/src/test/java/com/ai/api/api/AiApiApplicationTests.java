package com.ai.api.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
